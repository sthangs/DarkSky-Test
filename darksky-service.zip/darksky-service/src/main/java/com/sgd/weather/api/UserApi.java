package com.sgd.weather.api;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgd.weather.model.User;


public interface UserApi {

	@GetMapping(value = "/", produces = { "application/json" }, consumes = { "application/json" })
	default ResponseEntity<User> userGet(@RequestParam(value = "userId", required = true) String userId)
			throws Exception {

		return new ResponseEntity<User>(HttpStatus.OK);
	}

	@PostMapping(value = "/login", produces = { "application/json" }, consumes = { "application/json" })
	default ResponseEntity<User> userLogin(@Valid @RequestBody User user) throws Exception {
		
		return new ResponseEntity<User>(HttpStatus.OK);
	}

}
