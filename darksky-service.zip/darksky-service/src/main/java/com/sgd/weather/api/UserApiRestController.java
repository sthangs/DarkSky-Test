package com.sgd.weather.api;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgd.weather.model.User;


@RestController
@Validated
@CrossOrigin
public class UserApiRestController implements UserApi {
	private final UserApiDelegate delegate;

	@org.springframework.beans.factory.annotation.Autowired
	public UserApiRestController(UserApiDelegate delegate) {
		this.delegate = delegate;
	}

	public ResponseEntity<User> userGet(@RequestParam(value = "userId", required = true) String userId) throws Exception {

		return delegate.userGet(userId);
	}
	
	public ResponseEntity<User> userLogin(@RequestBody User user) throws Exception {

		return delegate.userLogin(user);
	}

}
