package com.sgd.weather.api;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.sgd.weather.model.User;

/**
 * A delegate to be called by the {@link UserApiController}}. Should be
 * implemented as a controller but without the
 * {@link org.springframework.stereotype.Controller} annotation. Instead, use
 * spring to autowire this class into the {@link UserApiController}.
 */


public interface UserApiDelegate {

  /**
   * @see UserApi#Get
   */
  default ResponseEntity<User> userGet(String userId) throws Exception {

    return new ResponseEntity<User>(HttpStatus.OK);
  }

  
  default ResponseEntity<User> userLogin(User user) throws Exception {

	    return new ResponseEntity<User>(HttpStatus.OK);
	  }
}
