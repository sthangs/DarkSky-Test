package com.sgd.weather.api;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.sgd.weather.model.User;

/**
 * A delegate to be called by the {@link UserApiController}}. Should be
 * implemented as a controller but without the
 * {@link org.springframework.stereotype.Controller} annotation. Instead, use
 * spring to autowire this class into the {@link UserApiController}.
 */

@Component
public class UserApiDelegateImpl implements UserApiDelegate {
  
  
  @Autowired
  public UserApiDelegateImpl() {
  
  }

  /**
   * @throws BOPAppException 
   * @see UserApi#sGet
   */
  public ResponseEntity<User> userGet(String userId) throws Exception {
    User rsp =null; //service.(userId);
    return new ResponseEntity<User>(rsp, HttpStatus.OK);
  }
  
  public ResponseEntity<User> userLogin(User user) throws Exception {
	  //user.setSuccess(true);
	  if(user.getEmail().equalsIgnoreCase("admin@gmail.com")){
			user.setUserRole("Admin"); //Show all tabs
			user.setUserName("Admin");
			user.setSuccess(true);
			}else{
				user.setSuccess(false);
			}
	    return new ResponseEntity<User>(user,HttpStatus.OK);
	  }

}
