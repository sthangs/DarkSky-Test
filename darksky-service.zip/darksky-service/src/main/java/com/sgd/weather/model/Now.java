package com.sgd.weather.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Now
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-10-10T17:27:33.768+05:30")

public class Now   {
  @JsonProperty("time")
  private String time = null;

  @JsonProperty("summary")
  private String summary = null;

  @JsonProperty("precipType")
  private String precipType = null;

  @JsonProperty("temperature")
  private String temperature = null;

  @JsonProperty("dewPoint")
  private String dewPoint = null;

  @JsonProperty("humidity")
  private String humidity = null;

  @JsonProperty("windSpeed")
  private String windSpeed = null;

  public Now time(String time) {
    this.time = time;
    return this;
  }

  /**
   * Get time
   * @return time
  **/
  @ApiModelProperty(value = "")

@Pattern(regexp="[0-9]+") @Size(min=1) 
  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public Now summary(String summary) {
    this.summary = summary;
    return this;
  }

  /**
   * Get summary
   * @return summary
  **/
  @ApiModelProperty(value = "")


  public String getSummary() {
    return summary;
  }

  public void setSummary(String summary) {
    this.summary = summary;
  }

  public Now precipType(String precipType) {
    this.precipType = precipType;
    return this;
  }

  /**
   * Get precipType
   * @return precipType
  **/
  @ApiModelProperty(value = "")


  public String getPrecipType() {
    return precipType;
  }

  public void setPrecipType(String precipType) {
    this.precipType = precipType;
  }

  public Now temperature(String temperature) {
    this.temperature = temperature;
    return this;
  }

  /**
   * Get temperature
   * @return temperature
  **/
  @ApiModelProperty(value = "")


  public String getTemperature() {
    return temperature;
  }

  public void setTemperature(String temperature) {
    this.temperature = temperature;
  }

  public Now dewPoint(String dewPoint) {
    this.dewPoint = dewPoint;
    return this;
  }

  /**
   * Get dewPoint
   * @return dewPoint
  **/
  @ApiModelProperty(value = "")


  public String getDewPoint() {
    return dewPoint;
  }

  public void setDewPoint(String dewPoint) {
    this.dewPoint = dewPoint;
  }

  public Now humidity(String humidity) {
    this.humidity = humidity;
    return this;
  }

  /**
   * Get humidity
   * @return humidity
  **/
  @ApiModelProperty(value = "")


  public String getHumidity() {
    return humidity;
  }

  public void setHumidity(String humidity) {
    this.humidity = humidity;
  }

  public Now windSpeed(String windSpeed) {
    this.windSpeed = windSpeed;
    return this;
  }

  /**
   * Get windSpeed
   * @return windSpeed
  **/
  @ApiModelProperty(value = "")


  public String getWindSpeed() {
    return windSpeed;
  }

  public void setWindSpeed(String windSpeed) {
    this.windSpeed = windSpeed;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Now now = (Now) o;
    return Objects.equals(this.time, now.time) &&
        Objects.equals(this.summary, now.summary) &&
        Objects.equals(this.precipType, now.precipType) &&
        Objects.equals(this.temperature, now.temperature) &&
        Objects.equals(this.dewPoint, now.dewPoint) &&
        Objects.equals(this.humidity, now.humidity) &&
        Objects.equals(this.windSpeed, now.windSpeed);
  }

  @Override
  public int hashCode() {
    return Objects.hash(time, summary, precipType, temperature, dewPoint, humidity, windSpeed);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Now {\n");
    
    sb.append("    time: ").append(toIndentedString(time)).append("\n");
    sb.append("    summary: ").append(toIndentedString(summary)).append("\n");
    sb.append("    precipType: ").append(toIndentedString(precipType)).append("\n");
    sb.append("    temperature: ").append(toIndentedString(temperature)).append("\n");
    sb.append("    dewPoint: ").append(toIndentedString(dewPoint)).append("\n");
    sb.append("    humidity: ").append(toIndentedString(humidity)).append("\n");
    sb.append("    windSpeed: ").append(toIndentedString(windSpeed)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

