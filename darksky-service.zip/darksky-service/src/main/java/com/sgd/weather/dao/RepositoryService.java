/*package com.sgd.weather.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sgd.weather.model.WeatherReport;

public interface  RepositoryService extends JpaRepository<WeatherReport, String>{
	

}
*/