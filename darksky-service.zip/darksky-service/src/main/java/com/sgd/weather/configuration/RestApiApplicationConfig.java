package com.sgd.weather.configuration;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestApiApplicationConfig {
	
  private RestTemplate getRestTemplate;
  private HttpHeaders httpHeaders;
  private HttpEntity<String> getHttpEntity;
  private Map<String, String> pathParams;

  @Autowired
  public RestApiApplicationConfig(RestTemplateBuilder restTemplateBuilder) {
      this.getRestTemplate = restTemplateBuilder.build();
      this.httpHeaders = new HttpHeaders();
      this.httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      this.httpHeaders.setContentType(MediaType.APPLICATION_JSON);
      //this.httpHeaders.set("Authorization","habbYH0PeR63pRNYsIp53LGUruOTbjBOpPC7zjm8Fk7Tyg8zZGaK9fy6uhCZ3LvbLn0o93pkAfA");
      this.getHttpEntity = new HttpEntity<>("parameters", httpHeaders);
  }
  

  private String taskListGetUrl="https://api.darksky.net/forecast";
  

  public String getTaskListGetUrl() {
	return taskListGetUrl;
}

public void setTaskListGetUrl(String taskListGetUrl) {
	this.taskListGetUrl = taskListGetUrl;
}

public RestTemplate getGetRestTemplate() {
    return getRestTemplate;
  }

  public void setGetRestTemplate(RestTemplate getRestTemplate) {
    this.getRestTemplate = getRestTemplate;
  }

  public HttpEntity<String> getGetHttpEntity() {
    return getHttpEntity;
  }

  public void setGetHttpEntity(HttpEntity<String> getHttpEntity) {
    this.getHttpEntity = getHttpEntity;
  }

  public Map<String, String> getPathParams() {
    return pathParams;
  }

  public void setPathParams(Map<String, String> pathParams) {
    this.pathParams = pathParams;
  }
}
