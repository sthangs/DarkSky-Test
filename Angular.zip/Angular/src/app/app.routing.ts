import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from "./modules/auth/login/login.component";
import { AppsComponent } from './modules/apps/apps.component';
import { HomeComponent } from './modules/home/home.component';
import { ManageUsersComponent } from './modules/manage-users/manage-users.component';
import { CreateSubscriberComponent } from './modules/manage-subscriptions/create-subscriber/create-subscriber.component';
import { QueuesComponent } from './modules/queues/queues.component';
import { AlertsComponent } from './modules/Alerts/alerts.component';

/*import {AddUserComponent} from "./add-user/add-user.component";
import {ListUserComponent} from "./list-user/list-user.component";
import {EditUserComponent} from "./edit-user/edit-user.component";*/

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'home', component: HomeComponent
    /*children: [
    {
      path: 'apps',
      component: AppsComponent,
      outlet:'one'
    }
  ] */
  },
  { path: 'manage-users', component: ManageUsersComponent },
  { path: 'queues', component: QueuesComponent },
  { path: 'create-subscriber', component: CreateSubscriberComponent },
  { path: 'alerts', component: AlertsComponent },
  /*{ path: 'add-user', component: AddUserComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'edit-user', component: EditUserComponent },*/
  { path: '', component: LoginComponent }
];

export const routing = RouterModule.forRoot(routes);
