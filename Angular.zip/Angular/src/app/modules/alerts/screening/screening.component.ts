import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AlertsScreeningModel } from '../../shared/models';
import { AlertsService } from '../../core/alerts.service';


@Component({
    selector: 'screening',
    templateUrl: './screening.component.html',
    styleUrls: ['./screening.component.css'],
})

export class ScreeningComponent implements OnInit {

    dataSource: MatTableDataSource<AlertsScreeningModel>;
    displayedColumns: string[] = ['alertedName', 'nII', 'inquiry', 'category', 'subCategory', 'date',
        'screeningConfiguration', 'primaryID', 'primaryCompanyName', 'currentQueue', 'alertStatus', 'projectId', 'pmAlert'];
    options: string[] = ['Yes', 'No'];
    activeSelectedValue: any;
    filterValues = { active: '' };
    @ViewChild('managerUserPaginator') paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    constructor(private alertsService: AlertsService) { }

    ngOnInit() {
        this.alertsService.getMessage().subscribe((reponse) => {
            this.dataSource = new MatTableDataSource<AlertsScreeningModel>(reponse);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.dataSource.filterPredicate = this.createFilter();
        });
    }

    createFilter() {
        let filterFunction = function (data, filter): boolean {
            let searchTerms = JSON.parse(filter)
            return data.active.toString().indexOf(searchTerms.active) != -1;
        }
        return filterFunction
    }

}