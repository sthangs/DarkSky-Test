import { Component, OnInit } from '@angular/core';
import { AlertsService } from '../core/alerts.service';
import { FormControl } from '@angular/forms';


@Component({
    selector: 'alerts',
    templateUrl: './alerts.component.html',
    styleUrls: ['./alerts.component.css'],
})

export class AlertsComponent implements OnInit {
    selectedIndex = 0;

    constructor() { }

    ngOnInit() {

    }


}