import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { UsersTaskViewService } from '../core/user-task-view.service.';

@Component({
  selector: 'app-admin-task-view',
  templateUrl: './admin-task-view.component.html',
  styleUrls: ['./admin-task-view.component.css']
})
export class AdminTaskViewComponent implements OnInit {

  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [ 'latitude', 'longitude', 'timezone' ,'summary' ,'temperature', 'humidity' ,'windSpeed'];
  options: string[] = ['Yes', 'No'];
  activeSelectedValue: any;
  elementDetail : any[]=[];
  filterValues = { active: '' };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('managerUserPaginator') paginator: MatPaginator;
  constructor(private usersTaskViewService: UsersTaskViewService) { }

  ngOnInit() {
      this.usersTaskViewService.listAdminTasks().subscribe((reponse) => {
        console.log(">>>>",reponse);
          this.elementDetail.push(reponse);

          this.usersTaskViewService.listAdminTasks1().subscribe((reponse) => {
        
            this.elementDetail.push(reponse);

              this.usersTaskViewService.listAdminTasks2().subscribe((reponse) => {
          
                this.elementDetail.push(reponse);

                this.usersTaskViewService.listAdminTasks3().subscribe((reponse) => {
          
                  this.elementDetail.push(reponse);
  
                  this.usersTaskViewService.listAdminTasks4().subscribe((reponse) => {
          
                    this.elementDetail.push(reponse);
    
                    this.usersTaskViewService.listAdminTasks5().subscribe((reponse) => {
          
                      this.elementDetail.push(reponse);
      
                      this.dataSource = new MatTableDataSource<any>(this.elementDetail);
                    
                  });
                  
                });
                
              });
                
              
            });
          });
            
            
          });

 
  }



  editClick(element) {
      console.log('Edit click - element info ' , element);
  }

}
