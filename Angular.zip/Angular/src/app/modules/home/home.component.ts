import { Component, OnInit, ViewChild, ElementRef, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { NavbarService } from '../core';
import { VERSION } from '@angular/material';
import { NavItem } from '../components/sidenav/nav-item';
import { LoginRestService } from '../auth/login/login-rest.service';
import { Router } from "@angular/router";
import { FlatTreeControl } from '@angular/cdk/tree';
import { Injectable } from '@angular/core';
import { BehaviorSubject, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DynamicDataSource, AuthService } from '../core'
import { DynamicDatabase, DynamicFlatNode } from '../shared/models';
import { Subscription } from 'rxjs'; 
import { MessageService } from 'src/app/message.service';



@Component({
  selector: 'app-home',
  providers: [DynamicDatabase],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  loggedInUser: any;
  moduleName: string='Load Entity';
  treeControl: FlatTreeControl<DynamicFlatNode>;
  dataSource: DynamicDataSource;
  userData:any;
  subscription: Subscription; 
  visible:any;
  uRole:any;
  getLevel = (node: DynamicFlatNode) => node.level;

  isExpandable = (node: DynamicFlatNode) => node.expandable;

  hasChild = (_: number, _nodeData: DynamicFlatNode) => _nodeData.expandable;
  constructor(public authService: AuthService,private navbarService: NavbarService, private router: Router,
    private loginService: LoginRestService, 
    private messageService: MessageService, 
    database: DynamicDatabase) {
    this.treeControl = new FlatTreeControl<DynamicFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new DynamicDataSource(this.treeControl, database);

    this.dataSource.data = database.initialData();
  }

  ngOnInit() { 
    this.uRole=this.authService.GetUserRole();

    this.subscription= this.messageService.getMessage().subscribe(message => {
      console.log("message ==> ",
      message);
      this.userData= message.key; 
      console.log(">>>"+this.userData);
      }); 
  }
  
  getRole() {
   
    /*if(uRole=="Supplier Admin"){
      this.visible = 'true';
      
    }else if(uRole=="Subscriber User"){
       
    }else if(uRole=="Supplier User"){

    }*/

  }
  getModule(modulename) {
    this.moduleName = modulename;
  }
  onClickMe() {

  }

  onLinkClick(module) {
    if(module.tab.textLabel =='Load Entity') {
       this.moduleName =module.tab.textLabel;
    }
  }


  ngAfterViewInit() {
    console.log(">>>called ngAfterViewInit");
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}
}





