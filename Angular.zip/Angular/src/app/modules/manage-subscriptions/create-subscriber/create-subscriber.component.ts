import { MatInputModule } from '@angular/material/input';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'create-subscriber',
    templateUrl: './create-subscriber.component.html',
    styleUrls: ['./create-subscriber.component.css']
})

export class CreateSubscriberComponent implements OnInit {


    constructor() {

    }

    ngOnInit(){
        
    }

    onSubmit(){

    }

}