import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { LoginRestService } from './login-rest.service';
import { MessageService } from 'src/app/message.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  registerForm: FormGroup;
  submitted: boolean = false;
  regSubmitted: boolean = false;
  isInvalidLogin: boolean = false;
  errorMsg: String;
  constructor(private formBuilder: FormBuilder, private router: Router, private loginService: LoginRestService, 
    private messageService: MessageService ) { }

  
  onSubmit() {
    this.submitted = true;
    console.info(this.loginForm.invalid);
    if (this.loginForm.invalid) {
      return;
    }
  
   this.loginService.doLogin(this.loginForm.value).subscribe((result) => {
      console.log("POST call successful value returned in body", 
      result);
      if(result != undefined && result.success){
        this.messageService.sendMessage(result); 
        this.router.navigate(['home']);
        
      } else if(result != undefined && !result.success){
        console.log("POST call successful value returned in body", 
        result);
       this.isInvalidLogin = result.success;
       this.errorMsg = result.message;
      }
    }, (err) => {
      console.log(err);
    });
    console.info(this.loginForm.value);
  }
 
  onRegisterSubmit() {
    this.regSubmitted = true;
    if (this.registerForm.invalid) {
      return;
    }
    this.loginService.doRegister(this.registerForm.value).subscribe((result) => {
      console.log("POST call successful value returned in body", 
      result);
      this.registerForm.reset();
    }, (err) => {
      console.log(err);
    });
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
}
