import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AuthService } from '../../core';

@Injectable({
  providedIn: 'root'
})

export class LoginRestService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  private extractData(res: Response) {
    let body = res;
    return body || {};
  }
  endpoint: String = 'http://localhost:8080/api/weather/';
  httpOptions: Object = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    withCredentials: true
  }

  doLogin(user): Observable<any> {
    console.log(user);
     return this.http.post<any>(this.endpoint + 'login', user, this.httpOptions).pipe(
       tap((msg) => {
        console.log(`Is User logged in successfully =${msg.success}`);
      }),
       map((response) => {
         this.authService.SetIsUserLogged('true');
         console.log("userRole",response.userRole);
         this.authService.SetUserRole(response.userRole);
         return response;
       }),
       catchError(this.handleError<any>('doLogin'))
     );
  }

  doRegister(user): Observable<any> {

    return this.http.post<any>(this.endpoint + 'register', user, this.httpOptions).pipe(
      tap((info) => console.log(`Added user w/ id=${info.message}`)),
      catchError(this.handleError<any>('doRegister'))
    );
  }

  saveSurveyDetails(surveyJson): Observable<any> {

    return this.http.post<any>(this.endpoint + 'saveSurevyDetails', surveyJson, this.httpOptions).pipe(
      tap((info) => console.log(`Added survey w/ id=${info.message}`)),
      catchError(this.handleError<any>('saveSurveyDetails'))
    );
  }

  getLoggedInUser(): Observable<any> {

    return this.http.get<any>(this.endpoint + 'getUserDetails', this.httpOptions).pipe(
      tap((user) => console.log(`Logged In User=${user.firstName}`)),
      catchError(this.handleError<any>('getLoggedInUser'))
    );
  }

  getAllUsers(): Observable<any> {
    console.log('get all users');
    return this.http.get<any>(this.endpoint + 'getAllUsers', this.httpOptions).pipe(
      tap((users) => console.log(`Users=${users}`)),
      catchError(this.handleError<any>('getAllUsers'))
    );
  }



  getSurveyDetails(user): Observable<any> {

    return this.http.post<any>(this.endpoint + 'getSurvey', user, this.httpOptions).pipe(
      tap((info) => console.log(`survey w/ id=${info.message}`)),
      catchError(this.handleError<any>('getSurveyDetails'))
    );
  }

  logout(): Observable<any> {

    return this.http.get<any>(this.endpoint + 'logout', this.httpOptions).pipe(
      tap((user) => {
        console.log(`Logout Use`);
      }),
      map((response) => {
        this.authService.SetIsUserLogged('false');
        return response;
      }),
      catchError(this.handleError<any>('logout'))
    );
  }


  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }


}
