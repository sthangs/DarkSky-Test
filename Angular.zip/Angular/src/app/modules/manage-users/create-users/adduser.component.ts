import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ManageUsersService } from '../../core';
import { ManageUsersModel } from '../../shared/models';
import { MatInputModule } from '@angular/material/input';

@Component({
    selector: 'add-users',
    templateUrl: './adduser.component.html',
    styleUrls: ['./adduser.component.css']
})
export class AddUsersComponent implements OnInit {
    
    constructor(private manageUsersService: ManageUsersService) { }

    ngOnInit() {
       
    }

}
