import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ManageUsersService } from '../core';
import { ManageUsersModel } from '../shared/models';

@Component({
    selector: 'manage-users',
    templateUrl: './manage-users.component.html',
    styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit {
    dataSource: MatTableDataSource<ManageUsersModel>;
    displayedColumns: string[] = ['subscriberName', 'subscriberDUNS', 'subscriberID', 'active', 'type', 'action'];
    options: string[] = ['Yes', 'No'];
    activeSelectedValue: any;
    filterValues = { active: '' };
    @ViewChild('managerUserPaginator') paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    constructor(private manageUsersService: ManageUsersService) { }

    ngOnInit() {
        this.manageUsersService.getMessage().subscribe((reponse) => {
            this.dataSource = new MatTableDataSource<ManageUsersModel>(reponse);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.dataSource.filterPredicate = this.createFilter();
        });
    }

    createFilter() {
        let filterFunction = function (data, filter): boolean {
            let searchTerms = JSON.parse(filter)
            return data.active.toString().indexOf(searchTerms.active) != -1;
        }
        return filterFunction
    }

    viewClick(element) {
        console.log('View click - element info ' , element);
    }

    editClick(element) {
        console.log('Edit click - element info ' , element);
    }

    actionChange(value) {
        this.filterValues.active = value;
        this.dataSource.filter = JSON.stringify(this.filterValues);
        console.log(value);
    }
}
