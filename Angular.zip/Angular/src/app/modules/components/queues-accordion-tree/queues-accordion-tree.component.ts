import { Component, OnInit, Injectable, Input } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { BehaviorSubject, Observable, of as observableOf } from 'rxjs';
import { QueuesNode, QueuesFlatNode } from '../../shared/models';

@Component({
    selector: 'queues-accordion-tree',
    templateUrl: './queues-accordion-tree.component.html',
    styleUrls: ['./queues-accordion-tree.component.css']
})
export class QueuesAccordionTreeComponent implements OnInit {
    @Input() header: any;
    @Input() headerDesc: any;
    @Input() fileTreeData: any;
    accordionExpanded: any;
    treeControl: FlatTreeControl<QueuesFlatNode>;
    treeFlattener: MatTreeFlattener<QueuesNode, QueuesFlatNode>;
    dataSource: MatTreeFlatDataSource<QueuesNode, QueuesFlatNode>;
    constructor() { }

    ngOnInit() {
        this.treeFlattener = new MatTreeFlattener(this.transformer, this._getLevel, this._isExpandable, this._getChildren);
        this.treeControl = new FlatTreeControl<QueuesFlatNode>(this._getLevel, this._isExpandable);
        this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
        if (this.fileTreeData && this.fileTreeData.length > 0) {
            this.dataSource.data = this.fileTreeData;
        }
        //  = this.buildFileTree(this.fileTreeData, 0);
    }

    /**
     * Build the file structure tree. The `value` is the Json object, or a sub-tree of a Json object.
     * The return value is the list of `FileNode`.
     */
    buildFileTree(obj: { [key: string]: any }, level: number): QueuesNode[] {
        return Object.keys(obj).reduce<QueuesNode[]>((accumulator, key) => {
            const value = obj[key];
            const node = new QueuesNode();
            node.nodeName = key;

            if (value != null) {
                if (value['value']) {
                    node.record = value['value']
                }
                if (value && Array.isArray(value['child'])) {
                    node.child = this.buildFileTree(value['child'], level + 1);
                }
            }

            return accumulator.concat(node);
        }, []);
    }

    transformer = (node: QueuesNode, level: number) => {
        return new QueuesFlatNode(!!node.child, node.nodeName, level, node.record);
    }

    private _getLevel = (node: QueuesFlatNode) => node.level;

    private _isExpandable = (node: QueuesFlatNode) => node.expandable;

    private _getChildren = (node: QueuesNode): Observable<QueuesNode[]> => observableOf(node.child);

    hasChild = (_: number, _nodeData: QueuesFlatNode) => _nodeData.expandable;
}
