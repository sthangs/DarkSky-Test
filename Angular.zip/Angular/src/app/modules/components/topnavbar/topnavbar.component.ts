import { Component, OnInit } from '@angular/core';
import { NavbarService, MessageService, AuthService } from '../../core';
import { LoginRestService } from '../../auth/login/login-rest.service';
import { Router } from "@angular/router";
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-topnavbar',
  templateUrl: './topnavbar.component.html',
  styleUrls: ['./topnavbar.component.css']
})
export class TopnavbarComponent implements OnInit {

  loggedInUser: any;
  subscription: Subscription;
  badgeCount: number;
  surveys: any;
  userRole:any;

  constructor(public navService: NavbarService, private router: Router,
    private loginService: LoginRestService, private messageService: MessageService,
    public authService: AuthService) {

  }

  ngOnInit() {
    this.userRole=this.authService.GetUserRole();
    console.log("from topnav",this.userRole);
    this.subscription = this.messageService.getMessage().subscribe(message => {
      console.log(" message ==>  ",
        message);
      this.loggedInUser = message.key;
     /* this.loginService.getSurveyDetails(this.loggedInUser).subscribe((data) => {
        console.log(" Survey POST call successful value returned in body",
          data);
        if (data.success) {
          this.badgeCount = data.message.length;
          this.surveys = data.message;
          this.userRole=this.userRole;
        } else {
          this.surveys = data.message;
        }

      }, (err) => {
        console.log("error ==> ", err);
      });*/
    });

  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }

  doLogout() {
    this.loginService.logout().subscribe((result) => {
      console.log("Logout call successful value returned in body",
        result);
      this.router.navigate(['login']);
      console.log(result);
    }, (err) => {

      console.log("error ==> ", err);
    });
  }

  openNewTab(survey) {
    console.log("survey url ---------->  ", survey.url);
    if (survey.url != "Survey not found") {
      var mywindow = window.open(survey.url, 'fullscreen=yes, status=0,scrollbars=1,resizable=1,location=1');
      // mywindow.document.write("<p id=\"text\">This is 'myWindow'</p>");
      window.onblur = () => {
        console.log("text === >  ", mywindow.document.getElementById("text").textContent);
      };
      setTimeout(() => {
        var elemDiv = document.createElement('p');
        elemDiv.innerHTML = 'Added element with some data';
        mywindow.document.body.appendChild(elemDiv);
        mywindow.focus();
        var myTag = mywindow.document.getElementsByTagName("body");

        myTag[0].addEventListener("click", getClickTypeNPosition, false);
        //console.log("text === >  ", mywindow.document.getElementById("text").textContent);

      }, 5000);

      //window.open(survey.url,'fullscreen=yes');
      // window.open(survey.url, "_blank","toolbar=yes,scrollbars=yes,resizable=yes,fullscreen=yes");
    }
  }
}

function getClickTypeNPosition(e) {

  //doSomething();
  // alert(event.target.text+"     :Text");
  //alert(event.target.tagName+"   :tag");
  alert(document.activeElement.id + "    :id");
  alert(document.activeElement.className + "    :className");
  alert(event.type + "    Event");
  alert(event.target + "  HREF");
  alert(document.URL + "  Home URL");
  var eventType = event.type;
  var eventTarget = event.target;
  var homeUrl = document.URL;

  var parentPosition = getPosition(e.currentTarget);
  var xPosition = e.clientX - parentPosition.x;
  var yPosition = e.clientY - parentPosition.y;

  alert("X--Y Coordinates\n" + xPosition + "---" + yPosition);

}


function getPosition(el) {
  var xPos = 0;
  var yPos = 0;

  while (el) {
    if (el.tagName == "BODY") {

      // deal with browser quirks with body/window/document and page scroll
      var xScroll = el.scrollLeft || document.documentElement.scrollLeft;
      var yScroll = el.scrollTop || document.documentElement.scrollTop;

      xPos += (el.offsetLeft - xScroll + el.clientLeft);
      yPos += (el.offsetTop - yScroll + el.clientTop);
    } else {

      // for all other non-BODY elements
      xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
      yPos += (el.offsetTop - el.scrollTop + el.clientTop);
    }

    el = el.offsetParent;
  }
  return {
    x: xPos,
    y: yPos
  };
}



