import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
  })
export class LoadEntityService {

    constructor(private http: HttpClient) { }


    endpoint1: String = 'http://localhost:8080/kie-server/services/rest/server/queries/processes/definitions?filter=GenericTPIDueDiligence&sortOrder=false&pageSize=100';
    httpOptions1: Object = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      withCredentials: true
    }

    listProcessDef(): Observable<any> {
      console.log("listProcessDef");
      return this.http.get<any>(this.endpoint1 + '', this.httpOptions1).pipe(
          tap((ListProcessDef) => console.log(`listProcessDef=${ListProcessDef}`)),
          catchError(this.handleError<any>('listProcessDef'))
        );
    }


    endpoint: String = 'http://localhost:8080/kie-server/services/rest/server/containers/containerID/processes/GenericTPIDueDiligenceProcess/';
    httpOptions: Object = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      withCredentials: true
    }

    loadEntity(LoadEntityModel): Observable<any> {
      
       return this.http.post<any>(this.endpoint + 'instances', LoadEntityModel, this.httpOptions).pipe(
         tap((msg) => {
          console.log(`load entity tap =${msg}`);
        }),
         map((response) => {
          console.log(`load entity tap response =${response}`);
           return response;
         }),
         catchError(this.handleError<any>('loadEntity'))
       );
    }

      private handleError<T>(operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
    
          // TODO: send the error to remote logging infrastructure
          console.error(error); // log to console instead
    
          // TODO: better job of transforming error for user consumption
          console.log(`${operation} failed: ${error.message}`);
    
          // Let the app keep running by returning an empty result.
          return of(result as T);
        };
      }
}
