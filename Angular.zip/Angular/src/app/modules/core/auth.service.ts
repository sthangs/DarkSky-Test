import { EventEmitter, Injectable } from '@angular/core';

@Injectable()
export class AuthService {
    constructor() { }
    IsUserLogged(): boolean {
        return localStorage.getItem('isLoggedIn') === 'true';
    }

    SetIsUserLogged(value) {
        localStorage.setItem('isLoggedIn', value);
    }

    SetUserRole(value) {
        localStorage.setItem('userRole', value);
    }

    GetUserRole(): any {
        console.log("authservc",localStorage.getItem('userRole'));
        return localStorage.getItem('userRole');
    }
}
