import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Http } from '@angular/http';

@Injectable()
export class ManageUsersService {

    constructor(private http: Http) { }

    getMessage() {
        return this.http.get('./assets/mock/mock.json')
            .pipe(map((response) => {
                let data = response.json()
                console.log(data);
                if (data['manageusers']) {
                    console.log(">>>>" ,data['manageusers']);
                    return data['manageusers'];
                }
                return null
            }));

    }
}
