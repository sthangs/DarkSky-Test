import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
  })
export class UsersTaskViewService {

    constructor(private http: HttpClient) { }

    endpoint: String = 'http://localhost:8080/api/weather/';
    httpOptions: Object = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      withCredentials: true
    }


   /* listUserTasks(): Observable<any> {
        console.log("listUserTasks");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/-6.669160/110", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel=${UsersTaskViewModel}`)),
            catchError(this.handleError<any>('listUserTasks'))
          );
      }*/

      listAdminTasks(): Observable<any> {
        console.log("listAdminTasks");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/37.287659/-121.942429/Campbell", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel`,{UsersTaskViewModel})),
            catchError(this.handleError<any>('listAdminTasks'))
          );
      }

      listAdminTasks1(): Observable<any> {
        console.log("listAdminTasks1");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/41.256538/-95.934502/Omaha", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel`,{UsersTaskViewModel})),
            catchError(this.handleError<any>('listAdminTasks1'))
          );
      }

      listAdminTasks2(): Observable<any> {
        console.log("listAdminTasks2");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/30.267153/-97.743057/Austin", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel`,{UsersTaskViewModel})),
            catchError(this.handleError<any>('listAdminTasks1'))
          );
      }

      listAdminTasks3(): Observable<any> {
        console.log("listAdminTasks3");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/-6.669160/110.914261/Niseko", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel`,{UsersTaskViewModel})),
            catchError(this.handleError<any>('listAdminTasks1'))
          );
      }

      listAdminTasks4(): Observable<any> {
        console.log("listAdminTasks3");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/34.685085/135.804993/Nara", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel`,{UsersTaskViewModel})),
            catchError(this.handleError<any>('listAdminTasks1'))
          );
      }

      listAdminTasks5(): Observable<any> {
        console.log("listAdminTasks3");
        return this.http.get<any>(this.endpoint + 'report/'+"71256e4b695d1cb46a5057c9c6ca55b4/-6.175110/106.865036/Jakarta", this.httpOptions).pipe(
            tap((UsersTaskViewModel) => console.log(`UsersTaskViewModel`,{UsersTaskViewModel})),
            catchError(this.handleError<any>('listAdminTasks1'))
          );
      }


      private handleError<T>(operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
    
          // TODO: send the error to remote logging infrastructure
          console.error(error); // log to console instead
    
          // TODO: better job of transforming error for user consumption
          console.log(`${operation} failed: ${error.message}`);
    
          // Let the app keep running by returning an empty result.
          return of(result as T);
        };
      }
}
