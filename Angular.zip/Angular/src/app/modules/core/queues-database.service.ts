import { Component, OnInit, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of as observableOf } from 'rxjs';
import { QueuesNode } from '../shared/models';
import { map } from 'rxjs/operators';
import { Http } from '@angular/http';

@Injectable()
export class QueuesDatabase {
    dataChange = new BehaviorSubject<QueuesNode>(undefined);

    get data(): QueuesNode { return this.dataChange.value; }

    constructor(private http: Http) {
        this.initialize().subscribe((data) => { });
    }

    initialize() {
        return this.http.get('./assets/mock/mock.json')
            .pipe(map((response) => {
                let data = response.json();
                if (data['queuesData']) {
                    this.dataChange.next(data['queuesData']);
                }
                return null;
            }));

    }
}