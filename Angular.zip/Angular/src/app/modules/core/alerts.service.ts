import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Http } from '@angular/http';

@Injectable()
export class AlertsService {

    constructor(private http: Http) { }

    getMessage() {
        return this.http.get('./assets/mock/mock.json')
            .pipe(map((response) => {
                let data = response.json()
                if (data['screening']) {
                    return data['screening'];
                }
                return null
            }));

    }
}
