import { Component, OnInit } from '@angular/core';
import * as SurveyEditor from 'surveyjs-editor';
import { LoginRestService } from '../auth/login/login-rest.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from "@angular/router";
import {MatSnackBar} from '@angular/material';


@Component({
  selector: 'app-apps',
  templateUrl: './apps.component.html',
  styleUrls: ['./apps.component.css']
})
export class AppsComponent implements OnInit {
  editor: SurveyEditor.SurveyEditor;
  surveyForm: FormGroup;
  users: any;
  survey: any;
  isSurveyVisible: boolean = false;
  
  constructor(private loginservice: LoginRestService, private fb: FormBuilder, private router: Router, public snackBar: MatSnackBar) {

  }

  ngOnInit() {
    this.surveyForm = this.fb.group({
      title: ['', Validators.required],
      url: ['', Validators.required],
      team: ['', Validators.required],
      users: ['', [Validators.required]]
    });
    
  }


  ngAfterViewInit() {
    console.log(" ngAfterViewInit survey Save Json: ", this.editor);
    this.loginservice.getAllUsers().subscribe((result) => {
      console.log("POST call successful value returned in body",
        result);
      if (result === undefined) {
        this.users = [];
      } else {
        this.users = result;
      }
    }, (err) => {

      console.log("error ==> ", err);
    });
    
  }

  showSurveyEditor = () => {
    let editorOptions = {
      showEmbededSurveyTab: false, generateValidJSON: true,
      showJSONEditorTab: false, showOptions: false, showPropertyGrid: false, questionTypes: ["text", "checkbox", "radiogroup", "dropdown", "boolean"]
    };
    this.editor = new SurveyEditor.SurveyEditor('surveyEditorContainer', editorOptions);
    console.log("ngOnInit : ");

    var surveySettingsAction = this.editor.toolbarItems().filter(function (item) {
      console.log("item==> ", item);
      return item.id === "svd-survey-settings";
    })[0];
    console.log("surveySettingsAction : ", surveySettingsAction);
    this.editor.toolbarItems.remove(surveySettingsAction);
    console.log("survey Save Json: ", this.editor.text);

    SurveyEditor.StylesManager.applyTheme("stone");
  }

  saveMySurvey = () => {
    console.log('Survey Json ----> called', this.survey.title);
    var surveyJson = JSON.parse(this.editor.text);

    Object.assign(this.survey, {
      surveyJson: {
        title: this.survey.title,
        pages: surveyJson.pages
      }
    });

    console.log('saveMySurvey called', this.survey);

    this.loginservice.saveSurveyDetails(this.survey).subscribe((result) => {
      console.log("POST call successful value returned in body",
        result);

        this.snackBar.open('Survey successfully Saved','', {
          duration: 1000
        });
        this.isSurveyVisible = false;
        this.surveyForm.reset();
       // this.snackBar.dismiss();
        //this.router.navigate(['home/apps']);
    }, (err) => {
      console.log(err);
    });
  }

  onSubmit() {
    if (this.surveyForm.invalid) {
      return;
    }
    console.log("survey form value ==>", this.surveyForm.value.title);
    this.isSurveyVisible = true;
    this.survey = this.surveyForm.value;
    setTimeout(() => {
      this.showSurveyEditor();

      var elem = document.getElementsByClassName("svd_commercial_text");
    console.log("surveySettingsAction : ", elem.length);
    if (elem != null && elem != undefined && elem.length != 0) {
      elem.item(0).remove();
    }
    this.editor.saveSurveyFunc = this.saveMySurvey;
    var editorJson = this.editor.text;
    console.log("editor Save Json: ", editorJson);
    }, 400);
   
    //let surveyDiv = document.getElementById('surveyEditorContainer');
   // surveyDiv.style.display = 'block';

    //let myDiv = document.getElementById('surveyForm');
    //myDiv.style.display = 'none';
  }
}
