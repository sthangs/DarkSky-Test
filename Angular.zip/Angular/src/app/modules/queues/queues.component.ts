import { Component, OnInit, Injectable } from '@angular/core';
import { QueuesDatabase } from '../core';

@Component({
    selector: 'queues',
    templateUrl: './queues.component.html',
    styleUrls: ['./queues.component.css']
})
export class QueuesComponent implements OnInit {
    dataSource: any;
    constructor(database: QueuesDatabase) {
        database.dataChange.subscribe(data => {
            if (data) {
                this.dataSource = data;
            }
        });
    }

    ngOnInit() { }


}
