export class UsersTaskViewModel {
    subscriberName: string;
    subscriberDUNS: string;
    subscriberID: string;
    active: string;
    type: string;
    constructor() { }
}
