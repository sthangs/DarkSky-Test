export class QueuesNode {
    child: QueuesNode[];
    record: string;
    nodeName: string
}

export class QueuesFlatNode {
    constructor(
        public expandable: boolean, public nodeName: string, public level: number, public record: any) { }
}