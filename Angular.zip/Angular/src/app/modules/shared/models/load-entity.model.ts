export class LoadEntityModel {
    dunsnumber: number;
    industry: string;
    constructor() { }
}
