export class ManageUsersModel {
    subscriberName: string;
    subscriberDUNS: string;
    subscriberID: string;
    active: string;
    type: string;
    constructor() { }
}
