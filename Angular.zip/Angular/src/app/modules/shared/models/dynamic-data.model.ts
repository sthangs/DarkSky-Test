export class DynamicFlatNode {
    constructor(public item: string, public level = 1, public expandable = false,
        public isLoading = false) { }
}

export class DynamicDatabase {
    dataMap = new Map<string, string[]>([
        ['Admin Management', ['Manage Users', 'Manage Subscribers']],
        // ['Vegetables', ['Tomato', 'Potato', 'Onion']],
        ['Manage Users', ['Create Users', 'Create Roles', 'Create Usergroups', 'Access Privilage']],
        ['Manage Subscribers', ['Create Subscribers', 'Create Markets', 'Create Queues', 'Screen Configuration',
            'Mapping Markets && Queues']]
    ]);

    rootLevelNodes: string[] = ['Admin Management'];

    /** Initial data from database */
    initialData(): DynamicFlatNode[] {
        return this.rootLevelNodes.map(name => new DynamicFlatNode(name, 0, true));
    }

    getChildren(node: string): string[] | undefined {
        return this.dataMap.get(node);
    }

    isExpandable(node: string): boolean {
        return this.dataMap.has(node);
    }
}