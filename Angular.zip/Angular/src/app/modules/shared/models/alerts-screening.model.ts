export class AlertsScreeningModel {
    alertedName: string;
    nII: string;
    inquiry: string;
    category: string;
    subCategory: string;
    date: string;
    screeningConfiguration: string
    primaryID: string;
    primaryCompanyName: string;
    currentQueue: string;
    alertStatus: string;
    projectId: string;
    pmAlert: string;
    constructor() { }
}
