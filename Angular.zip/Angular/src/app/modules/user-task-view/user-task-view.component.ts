import { Component, OnInit, ViewChild} from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { UsersTaskViewModel} from '../shared/models/user-task-view.model';
import { UsersTaskViewService } from '../core/user-task-view.service.';

@Component({
  selector: 'user-task-view',
  templateUrl: './user-task-view.component.html',
  styleUrls: ['./user-task-view.component.css']
})
export class UserTaskViewComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [ 'name', 'travelType', 'source','destination','fromDate','toDate','paymentInfo'];
  options: string[] = ['Yes', 'No'];
  activeSelectedValue: any;
  filterValues = { active: '' };
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('managerUserPaginator') paginator: MatPaginator;
  constructor(private usersTaskViewService: UsersTaskViewService) { }
  user:any;

  ngOnInit() {
      
      /*this.usersTaskViewService.listUserTasks().subscribe((reponse) => {
          this.dataSource = new MatTableDataSource<any>(reponse);
          // this.dataSource.filter = "Reserved".trim().toLowerCase();
           this.dataSource.sort = this.sort;
           this.dataSource.paginator = this.paginator;
      });*/
  }

  /*viewClick(element) {
      console.log('View click - element info ' , element);
      this.usersTaskViewService.showTaskForm().subscribe((reponse) => {
        console.log("Form Shown" , reponse);
      });
  }*/

  // viewClick(element) {
  //     console.log(">>???",element['task-id']);
  // let url = 'http://localhost:8080/kie-server/services/rest/server/containers/'+element['task-container-id']+'/forms/tasks/'+element['task-id']+'/content';   
  // window.open(url, '_blank');
  // }

  editClick(element) {
      console.log('Edit click - element info ' , element);
  }

}
