import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { ManageUsersModel } from '../shared/models';
import { MatInputModule } from '@angular/material/input';
import { LoadEntityService } from '../core/load-entity.service';
import {MatSnackBar} from '@angular/material';

@Component({
    selector: 'load-entity',
    templateUrl: './loadentity.component.html',
    styleUrls: ['./loadentity.component.css']
})
export class LoadEntityComponent implements OnInit {
    
    constructor(private loadEntityService: LoadEntityService,public snackBar: MatSnackBar) { }
    dunsno:any;
    industry:any;
    ngOnInit() {
       this.industry = 'garments';
    }

    getContainerVersion(process){
        var container_id = process['container-id'];

        return parseInt(container_id.split('_1.0.')[1]);
    }

    getContainerName(containerID){
        

        return containerID.split('_')[0] + "_1.0.";
    }

    sortNum(num1, num2){
        return num1 - num2;
    }

    loadEntity(){
        console.log(this.dunsno,">>>>>",this.industry);
        var latestVersion = '';
    
        this.loadEntityService.listProcessDef().subscribe((reponse) => {
            console.log("listProcessDef" , reponse);

            console.log("listProcessDef only container id array>" , reponse['processes'][0]['container-id']);

            var containers = reponse['processes'].map(this.getContainerVersion);
            containers.sort(this.sortNum);        // First sort the elements of fruits 
            containers.reverse();  

            latestVersion = '' + this.getContainerName(reponse['processes'][0]['container-id']) + containers[0];
            console.log("containers: " ,containers);
            console.log("latest version : " ,latestVersion);
            
            this.loadEntityService.endpoint= this.loadEntityService.endpoint.replace("containerID", latestVersion);
        
            this.loadEntityService.loadEntity({dunsnumber:this.dunsno,industry:this.industry}).subscribe((reponse) => {
                console.log("comp ts file" , reponse);
                this.snackBar.open('Work Flow Initiated','', {
                    duration: 3000
                });
            });

            this.snackBar.open('Invoked Latest deployed version','', {
                duration: 3000
              });
          });

          
    }


}
