import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';
import * as SurveyEditor from 'surveyjs-editor';

@Component({
  selector: 'app-surveyeditor',
  templateUrl: './surveyeditor.component.html',
  styleUrls: ['./surveyeditor.component.css']
})
export class SurveyeditorComponent implements OnInit {
  editor: SurveyEditor.SurveyEditor;
  constructor() { }

  ngOnInit() {
    console.log("ngOnInit : ");
    let editorOptions = {showEmbededSurveyTab: false, generateValidJSON : true, 
      showJSONEditorTab:false, showOptions:false, showPropertyGrid: false, questionTypes: ["text", "checkbox", "radiogroup", "dropdown", "boolean"]};
    this.editor = new SurveyEditor.SurveyEditor('surveyEditorContainer', editorOptions);

    var surveySettingsAction = this.editor.toolbarItems().filter(function(item) {
      console.log("item==> ", item);
      return item.id === "svd-survey-settings";
    })[0];
    console.log("surveySettingsAction : ", surveySettingsAction);
    this.editor.toolbarItems.remove(surveySettingsAction);
  }

  ngAfterViewInit() {
    var elem = document.getElementsByClassName("svd_commercial_text");
      console.log("surveySettingsAction : ", elem.length);
      if(elem != null && elem != undefined && elem.length !=0){
        elem.item(0).remove();
      }
   /* setTimeout(() => {
      
    }, 3000);*/
    
  }
  
  

  
  
}
