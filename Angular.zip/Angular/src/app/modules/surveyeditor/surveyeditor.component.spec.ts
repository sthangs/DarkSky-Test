import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyeditorComponent } from './surveyeditor.component';

describe('SurveyeditorComponent', () => {
  let component: SurveyeditorComponent;
  let fixture: ComponentFixture<SurveyeditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveyeditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyeditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
