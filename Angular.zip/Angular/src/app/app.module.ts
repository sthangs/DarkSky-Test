import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
  MatFormFieldModule
} from '@angular/material';

import { AppComponent } from './app.component';
import { LoginComponent } from './modules/auth/login/login.component';
import { routing } from "./app.routing";
import { TopnavbarComponent } from './modules/components/topnavbar/topnavbar.component';
import { SidenavComponent } from './modules/components/sidenav/sidenav.component';
import { NavbarService, AuthService, ManageUsersService, QueuesDatabase, AlertsService } from './modules/core';
import { HomeComponent } from './modules/home/home.component';
import { ManageUsersComponent } from './modules/manage-users/manage-users.component';
import { AddUsersComponent } from './modules/manage-users/create-users/adduser.component';
import { CreateSubscriberComponent } from './modules/manage-subscriptions/create-subscriber/create-subscriber.component';
import { QueuesComponent } from './modules/queues/queues.component';
import { QueuesAccordionTreeComponent } from './modules/components/queues-accordion-tree/queues-accordion-tree.component';
import { AlertsComponent } from './modules/Alerts/alerts.component';
import { ScreeningComponent } from './modules/Alerts/Screening/screening.component';
import { LoadEntityComponent } from './modules/loadentity/loadentity.component';
import { UserTaskViewComponent } from './modules/user-task-view/user-task-view.component';
import { MessageService } from './message.service';
import { AdminTaskViewComponent } from './modules/admin-task-view/admin-task-view.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TopnavbarComponent,
    SidenavComponent,
    HomeComponent,
    ManageUsersComponent,
    CreateSubscriberComponent,
    AddUsersComponent,
    QueuesComponent,
    QueuesAccordionTreeComponent,
    AlertsComponent,
    ScreeningComponent,
    LoadEntityComponent,
    UserTaskViewComponent,
    AdminTaskViewComponent
  ],
  imports: [
    BrowserModule,
    routing,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    BrowserAnimationsModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports: [
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    MatFormFieldModule
  ],
  providers: [NavbarService, MessageService, AuthService, ManageUsersService, QueuesDatabase, AlertsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
